$(document).on('change',".currency-country",function(){
    var country = $(this).val();
    $.ajax({
        url : site_url + "frontend/home/currency_convertor/"+country,
        dataType : 'json',
        success : function(data){
            window.location.reload();
        }
    });
});
