/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function() {
    $('#search-box').typeahead({
        onSelect: function(item) {
            jQuery('#searchkey').val(item.value);
        //            $.ajax({
        //                url: site_url + "frontend/home/get_country",
        //                data: {
        //                    id: item.value
        //                },
        //                //dataType: "json",
        //                success: function(result) {
        //                    $(".change_view").html('');
        //                    $(".change_view").html(result);  
        //                }
        //            });
        },
        ajax: {
            url: site_url + "get_country",
            timeout: 500,
            displayField: 'name',
            method: "get",
            //            preProcess: function(parsedResponse) {
            //              
            //            },
            preDispatch: function(query) {
                return {
                    search: query
                }
            },
            preProcess: function(data) {                
                if (data.success === false) {
                    return false;
                }
                var dataset = [];
                for (i = 0; i < data.length; i++) {
                    dataset.push({
                        id: data[i].id,
                        name: data[i].name
                    });
                }
                               
                if (data.length == 0) {
                    dataset.push({
                        id:1,
                        name: "Noresults" 
                    });
                }
                return dataset;
            // We good!
            //                return data;
            }
        }
    }); 
    
    $('.search').click(function(e){
        e.preventDefault();
        search = $('#search-box').val();
        if(search == '' || search==null){
            $('#error').show();
        }else
            window.location = site_url + "search?s=" + search ;
        
    });
    
    
    $(document).on('change','#type',function(){
        if($('#continent_id').val()){
            var continentid=$('#continent_id').val();
        }
        if($('#country_id').val()){
            var countryid=$('#country_id').val();
        }
        var val=$('#type').val();
        $.ajax({
            url: site_url+"get_category",
            cache: false,
            type: "GET",
            dataType:'json',
            data: {
                id : val,
                continentid:continentid,
                countryid:countryid
                   
            },
            success: function(data){ 
                
                $('.top-destination').hide();
                $('.other-destination').html('');
                $('.other-destination').html(data.view);
                var html_duration='';
                html_duration='<select name="duration" class="form-control" id="duration">';
                $.each(data.durations.duration, function(k, v) { 
                    if(k==0){
                        html_duration += '<option value="'+k+'">All</option>';                 
                    }else{
                        html_duration += '<option value="'+k+'">'+(v-1)+' night '+v+' days</option>';                 
                    }
                });
                html_duration +="</select>";
                $(".duration").html(html_duration);
            }
            
        });
    });
    $(document).on('change','#duration',function(){
        //        alert($('#category_id').val())
        if($('#category_id').val()){
            var category_id=$('#category_id').val();
        }
        if($('#continent_id').val()){
            var continentid=$('#continent_id').val();
        }
        if($('#country_id').val()){
            var countryid=$('#country_id').val();
        }
        var val=$('#duration').val();
        $.ajax({
            url: site_url+"get_duration",
            cache: false,
            type: "GET",
            dataType:'json',
            data: {
                id : val,
                continentid:continentid,
                countryid:countryid,
                category_id:category_id
                   
            },
            success: function(data){   
                $('.top-destination').hide();
                $('.other-destination').empty();
                $('.other-destination').html(data.view);
            }
            
        });
    });
    $(document).on('click','.continent',function(){
        var html_country='';
        elem =$(this);
        $.ajax({
            url: site_url + "listpackage",
            data: {
                continent_id : $(this).attr('data')
            },
            dataType: "json",
            success: function(data) {
               
                
                $('.dropdown-listing').remove();
                $('.top-destination').hide();
                $('.other-destination').html('');
                $('.other-destination').html(data.view);
                var html_country='';
                
                html_country='<ul class="dropdown-listing">';
                $.each(data.countries, function(k, v) {
                    if(k!='')		
                        
                        html_country += '<li><a href="javascript:void(0)" class="countries" data="'+k+'">'+v+'</a></li>';                 
                });
                html_country +="</ul>";
                
                elem.parent(".div-listing").append(html_country);
                elem.parents(".div-listing").addClass('open');
            }
        });
       
               
    });
    $(document).on('click','.countries',function(){
        
        $.ajax({
            url: site_url + "listpackage",
            data: {
                country_id : $(this).attr('data')
            },
            dataType: "json",
            success: function(data) {
                $('.top-destination').hide();
                $('.other-destination').html('');
                $('.other-destination').html(data.view);
                
            }
        });
       
               
    });
    
     
   
});