<!DOCTYPE html>
<html lang="en">
    <head>
   <!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
$.src="//v2.zopim.com/?3BC4pJyOg1LTKFYkZT2cNSQpDk0Cx0OY";z.t=+new Date;$.
type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
</script>
<!--End of Zopim Live Chat Script-->
                    <title>Holidays Box </title>
            <meta name = "keywords" content = "">
            <meta name = "DESCRIPTION" content = "">

                <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <!-- Latest compiled and minified CSS -->
        <link type="text/css" rel="stylesheet" href="http://www.holidaysbox.com/assets/frontend/css/bootstrap.css" />
<link type="text/css" rel="stylesheet" href="http://www.holidaysbox.com/assets/frontend/css/style.css" />
<link type="text/css" rel="stylesheet" href="http://www.holidaysbox.com/assets/frontend/css/colorbox.css" />
<link type="text/css" rel="stylesheet" href="http://www.holidaysbox.com/assets/frontend/css/font-awesome.min.css" />
<link type="text/css" rel="stylesheet" href="http://www.holidaysbox.com/assets/frontend/css/ionicons.min.css" />
<link type="text/css" rel="stylesheet" href="http://www.holidaysbox.com/assets/frontend/css/slicknav.css" />
<script type="text/javascript" src="http://www.holidaysbox.com/assets/js/jquery.min-1.7.1.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/js/common.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/js/placeholder.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/frontend/js/jquery-1.10.2.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/frontend/js/bootstrap-slider.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/frontend/js/bootstrap.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/frontend/js/jqeasy.dropdown.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/frontend/js/jquery.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/frontend/js/jquery.colorbox.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/frontend/js/typeahead.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/frontend/js/frontend.js"></script>
<script type="text/javascript" src="http://www.holidaysbox.com/assets/frontend/js/jquery.slicknav.js"></script>
<script type="text/javascript" defer="defer">var site_url="http://www.holidaysbox.com/";</script>        <script type="text/javascript">
            var $ = jQuery.noConflict();
            function processForm() {
                $(".newsletter").removeClass('success');
                $(".newsletter").removeClass('error');
                $(".newsletter").text();
                var email = $('#InputEmail').val();
                var re = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}/igm;
                if (!re.test(email)) {
                    $(".newsletter").text("Please Enter Valid Email Address");
                    return false;
                } else {
                    var url = site_url + 'newsletter';
                    $.ajax({
                        url: url,
                        type: 'GET',
                        dataType: 'json',
                        data: {
                            name: email
                        },
                        success: function (data) {
                            $(".newsletter").text(data.message);
                            if (data.error == 1) {
                                $(".newsletter").text(data.message);
                            } else if (data.success == 1) {
                                $(".newsletter").text(data.message);

                            }
                            $('#InputEmail').val("");

                        }
                    });
                }
            }
            $(document).ready(function () {
                $("#newsletter-popup").hide();
                $("#newletter").click(function () {
                    $("#newsletter-popup").slideToggle("slow");
                });
            });



            $(document).ready(function () {
                $('#menu').slicknav();
            });
        </script>
        <link rel='stylesheet' id='style-css'  href='http://www.holidaysbox.com/assets/frontend/css/jquery.fancybox.css' type='text/css' media='all'>
            <div id="popup"><a class="fancybox-effects-a" href="#inline" title=""></a>
        <div style="display:none;">
            <div id="inline">
                <div style="background: #fff; padding: 20px; display: block;">
                    <h3 class="page-header" style="text-align:center">Welcome to Holidaybox</h3>
                    <div class="destinaton-module">
                        <div id="carousel-gene1" class="" data-ride="carousel">
                                                        <div class="carousel-inner">
                                                                    <div class="item clearfix active"><!-- slides -->
                                        <ul class="nav nav-pills">
                                                                                            <li>
                                                    <div class="product-listion">
                                                                                                                <a class="product-img" href="http://www.holidaysbox.com/poland/central-europe-blend"><img src="http://www.holidaysbox.com/uploads/thumbnails/Krakow.jpg" height="150" width="215" title="Central Europe Blend" alt="Central Europe Blend" /></a>
                                                        <div class="product-price"><span class="pricesymbol">`</span>
                                                            108000 ONWARDS                                                        </div>
                                                        <div class="product-details">
                                                            <h2><a href="http://www.holidaysbox.com/poland/central-europe-blend">Central Europe Blend</a></h2>
                                                            <h3>Europe - Poland</h3>
                                                        </div>
                                                    </div>
                                                </li>
                                                                                    </ul>
                                    </div>
                                                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--        <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDKw1I9ZlI-piCBp2zXSuviBDVRjju-aYI&sensor=true&libraries=adsense"> </script>        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>        <script type="text/javascript" src="http://www.webestools.com/google_map_gen.js?lati=37.0625&long=-95.6770&zoom=4&width=675&height=400&mapType=normal&map_btn_normal=yes&map_btn_satelite=yes&map_btn_mixte=yes&map_small=yes&marqueur=yes&info_bulle=hello"></script>-->
</head>
<body class="js">
    <!--header section-->
    <div class="header-section">
        <div class="center-block">
            <h1 class="logo innerpage"><a href="http://www.holidaysbox.com/"><img src="http://www.holidaysbox.com/assets/frontend/image/logo.png" width="300" title="Holidays Box" alt="Holidays Box"/></a></h1>
        </div>
        <div class="follow-module">
            <ul class="nav nav-pills">
                <li class="sociali facebook"><a href="https://www.facebook.com/holidaysbox" target="_blank" title="Like us on Facebook"><i class="fa fa-facebook"></i></a></li>
                <li class="sociali twtr"><a href="https://twitter.com/holidaysbox" target="_blank" title="Follow us on Twitter"><i class="fa fa-twitter"></i></a></li>
                <li class="sociali p"><a href="#" title="Follow us on Pinterest"><i class="fa fa-pinterest"></i></a></li>
            </ul>
        </div>
        <div class="menu">
            <div class="center-block-menu">
                <div class="left-menu pull-left">
                    <div class="right-menu pull-left"> <a href="http://www.holidaysbox.com/destinations">
                            <h3 class="newletter menua" style="padding: 0px 15px;">Holiday Destinations</h3>
                        </a> </div>
                    <div class="menu-container">
                        <ul class="nav nav-pills pull-left"  id="menu">
                          <!--<li class=""> <a class="menua"  href="http://www.holidaysbox.com/destinations">Holiday Destinations </a></li>-->
                            <li class="active menuli"><a class="menua"  href="http://www.holidaysbox.com/">Home</a></li>
                                                            <li class="menuli "><a class="menua" href="http://www.holidaysbox.com/about-us">About Us</a></li>
                                                            <li class="menuli "><a class="menua" href="http://www.holidaysbox.com/faq">Faq</a></li>
                                                            <li class="menuli "><a class="menua" href="http://www.holidaysbox.com/careers">Careers</a></li>
                                                            <li class="menuli "><a class="menua" href="http://www.holidaysbox.com/mice-tours">MICE Tours</a></li>
                            <!--<li class=""> <a class="menua"  href="">MICE Tours </a></li>-->
                            <li class="menuli"> <a style="border-right:none !important" class="menua"  href="http://www.holidaysbox.com/contact-us">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="right-menu pull-right">
                    <h3 class="newletter" id="newletter">Newsletter<img class="plus" src="http://www.holidaysbox.com/assets/frontend/image/plus-icon.png" alt=""/></h3>
                    <div class="newsletter-popup clearfix" id="newsletter-popup" style="display:none">
                                                <div class="newsletter"> </div>
                        <div class="row">
                            <div class="col-lg-8 col-xs-8 no-padding" style="padding-right: 0px;"> <input type="email" name="email" value="" id="InputEmail" placeholder="Enter Email ID" class="form-control newsletter-input" style=""  /> </div>
                            <div class="col-lg-4 col-xs-4"><a onclick = "processForm();" class = "btn btn-primary">SUBMIT</a></div>
                        </div>
                    </div>
                </div>
                <!--<div class="contact-module">                		<a href="#" class="pop-btn" data-toggle="popover" data-html="true" data-content="<div><b>Popover Example</b> 1 - Content</div>" title="Popover Example <b>1</b> - Title"><span class="glyphicon glyphicon-map-marker"></span></a>                                                <a href="#" tabindex="0" class="btn btn-lg btn-danger pop-btn" role="button" data-toggle="popover" title="Dismissible popover" data-content="And here's some amazing content. It's very engaging. Right?">Dismissible popover</a>                                                <a data-original-title="Delete" href="#" title="" data-toggle="tooltip" data-placement="right" class="pop-btn confirm clr-red"><i class="fa fa-trash-o "></i></a>                                                        <address>                                    <abbr title="Phone"><strong><span class="circle-blue"><i class="glyphicon glyphicon-phone-alt tele-icon"></i></span> Call Us:</strong></abbr> 0091-9833835566  /   0091-9322451334<br>                                    <span style="padding-left:70px"><strong><span class="circle-blue"><i class="glyphicon glyphicon-envelope tele-icon"></i></span> Email US:</strong> <a href="mailto:info@holidaysbox.com">info@holidaysbox.com</a></span>                                </address>                            </div>--> </div>
        </div>
    </div>
    <div class="banner"> <!--banner-->
                        <div class="banner-module">
                    <div class="overlay"></div>
                    <div class="center-section">
                        <!--<h2 class="static-header"></h2>-->
                    </div>
                </div>
                            <div class="bottom-slide ">
                <div class="slide-center_section  row">
                                            <div class="col-sm-2 col-md-2 col-lg-2"> 
                            <span class="pull-left">
                                <p class="select-text">SELECT YOUR</p>
                                <h1 class="holiday-text">HOLIDAYS</h1>
                            </span> 
                        </div>
                                            <div class="col-sm-10 col-md-10 col-lg-10 right-box ">
                        <div class="pull-left">
                            <form action="http://www.holidaysbox.com/search" id="formsearch"  method="post" accept-charset="utf-8">                            
                            <input type="text" value="" class="form-control pull-left search-box typeahead" id="search-box" placeholder="Enter your destination:Country" autocomplete="off" style="width:530px; margin: 0px;">
                            <input type="hidden" id="searchkey" name="searchkey" class="form_control"/>
                            <input type="submit" class="btn btn-info green-btn search" id="search" value="Search"/>
                            <div class="alert alert-danger clear" id="error" style="display:none; padding:7px 10px;">Required</div>
                            
</form> </div>
                        <span class="pull-right list-style"><i><a href="http://www.holidaysbox.com/destinations" class="glyphicon glyphicon-th" title="List view">&nbsp;</a></i> <i><a href="http://www.holidaysbox.com/mapview" class="glyphicon glyphicon-globe" title="Map view">&nbsp;</a></i></span> </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-6991837-68', 'auto');
        ga('send', 'pageview');

    </script>
<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 849402052;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/849402052/?guid=ON&amp;script=0"/>
</div>
</noscript>

<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '227441094429491'); // Insert your pixel ID here.
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=227441094429491&ev=PageView&noscript=1"
/></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->
<script type="text/javascript">
    window._tfa = window._tfa || [];
    _tfa.push({ notify: 'action',name: 'Visit_Seychelles' });
</script>
<script src="//cdn.taboola.com/libtrc/tsbi-sc/tfa.js"></script>
<script>
    $(document).ready(function(){
        $("#new_captcha").click(function() {   
            $.ajax({
                url: "http://www.holidaysbox.com/frontend/enquiries/captcha_refresh"
            }).done(function(data) {
                $("#captcha").empty();
                $("#captcha").html(data);
            });
        });
    });
</script>
<div class="content-section">
    <div class="center-section" style="padding:7px">
        <h3 class="blue-heading">Enquiry</h3>
        <div class="row"><div class="col-lg-8 no-padding"><form action="http://www.holidaysbox.com/enquire" method="post" accept-charset="utf-8">            <div class="form-group">
                <label>Full Name</label>                <input type="text" name="name" value="" id="name" class="form-control" placeholder="Enter Name" required="1"  />                            </div>
            <div class="row"><div class="form-group col-lg-6 no-padding">
                <!--<label for="allCountries">* Select Package</label><br>-->
                <label>Select Package</label><br>
                                <select name="package" class="form-control">
<option value="2">Serene Seychelles </option>
<option value="3">Magical Maldives</option>
<option value="4">Phenomenal Poland</option>
<option value="5">Amazing West Coast with Hawaii</option>
<option value="6">Gorgeous Greece</option>
<option value="7">Glimpses of Greece</option>
<option value="8">Greece Getaway</option>
<option value="9">Inspiring Iceland</option>
<option value="10">Magnificent Morocco</option>
<option value="11">Stunning Slovenia</option>
<option value="12">Reunion Island</option>
<option value="13">Majestic Mauritius</option>
<option value="14">Terrific Turkey</option>
<option value="15">Beguiling Bulgaria</option>
<option value="16">Zoom to Zimbabwe</option>
<option value="17">Zimbabwe Exploration</option>
<option value="18">Memorable Madagascar</option>
<option value="19">Empirical Egypt</option>
<option value="20">Exclusive Egypt</option>
<option value="21">Mauritius and The Reunion Island</option>
<option value="22">Karismatic Koh Samui </option>
<option value="23">Idyllic Italy</option>
<option value="24">The Grand Baltic Trip</option>
<option value="25">Bombastic Brazil</option>
<option value="26">Brazilian Samba</option>
<option value="27">Unforgettable Uganda</option>
<option value="28">Leisurely Lebanon</option>
<option value="29">Magnificent  Mexico</option>
<option value="30">Kinetic Korea</option>
<option value="31">Discover Lebanon</option>
<option value="32">Classic Myanmar</option>
<option value="33">Treasures of Jordan</option>
<option value="34">Jewels of Jordan</option>
<option value="35">Exciting Ecuador</option>
<option value="36">Jump to Jordan</option>
<option value="38">Simply Nepal</option>
<option value="39">Majestic Nepal</option>
<option value="40">Kenyan Safari</option>
<option value="42">Scenic Sri Lanka</option>
<option value="43">Splendid Seychelles</option>
<option value="44">Wild Kenya</option>
<option value="45">Kenyan Quest</option>
<option value="46">Golden Triangle Package</option>
<option value="47">Outstanding Oman</option>
<option value="48">Zanzibar Island Escape</option>
<option value="49">Ultimate Uzbekistan</option>
<option value="50">Bhutan Diaries</option>
<option value="51">Bespoke Algarve Portugal</option>
<option value="52">Central Europe Blend</option>
<option value="53">Iceland and Finland Fusion</option>
<option value="54">Experience Egypt and Nile Cruise</option>
<option value="55">Absolute Armenia </option>
<option value="56">Hongkong and macau</option>
<option value="57">True Bali Honeymoon Experience</option>
<option value="58">Gems of Georgia</option>
<option value="59">Constance Ephelia Seychelles Package</option>
<option value="60">Discover Croatia</option>
<option value="61">Tantalizing Taiwan</option>
<option value="62">Seychelles Extended Weekend Budget</option>
<option value="63">Romance in Reunion Island</option>
<option value="64">The Fijian Dream Honeymoon Package</option>
<option value="65">Ultimate Seychelles Honeymoon Experience</option>
</select>                            </div>
            <div class="form-group col-lg-6">
                <label>Email ID</label>                <input type="email" name="email" value="" id="email" class="form-control" placeholder="Enter email id" required="1"  />                            </div></div>
            <div class="form-group">
                <label>Contact number</label>                <input type="text" name="number" value="" id="number" class="form-control" placeholder="Enter Number" required="1"  />                            </div> 
            <div class="form-group">
                <label>Message</label>                <textarea name="message" cols="40" rows="3" id="message" class="form-control" required="1" ></textarea>                            </div>
            <div class="row"><div class="form-group col-lg-6 no-padding">
                <!--<img src="assets/frontend/image/download.jpg" alt=""/><br>-->

<!--<input id="code" class="form-control" type="text" placeholder="Enter captcha">-->
                <!--<p><span id="captcha"></span> &nbsp;&nbsp;<a href="javascript:void(0)" id="new_captcha"><img src="" height="20px" width="20px" alt="Reload Captcha"/></a></p>-->
                <!--<label for="captcha2">* Type the numbers.</label><br>-->
                <!--<p><input type="text" name="cap" id="code" class="form-control" onclick="if(this.value=='Please type in the code here'){this.value='';}" onblur="if(this.value==''){this.value='Please type in the code here';}" value="Please type in the code here" /></p>-->  
             </div></div>
            <div class="clearfix">&nbsp;</div>
            <!--<button class="btn btn-info green-btn " type="button">Submit</button>-->
            <input type="submit" name="submit" value="Submit" class="btn btn-info green-btn" style="margin:0"  /></form>            <div class="clearfix">&nbsp;</div>
            <p>&nbsp;</p>
        </div></div>
    </div>
</div>
<div class="clearfix">&nbsp;</div>
<div class="content-bottom">
  <h2 style="text-align:center" class="bottom-headding">Holiday Box Type</h2>
  <div class="center-section type-module">
    <ul class="nav nav-pills">
	      <li class="circle-box"> <a class="" href="http://www.holidaysbox.com/holidaysbox-special"><img class="cicle-image" width="100" height="100" title="" alt="" src="http://www.holidaysbox.com/uploads/thumbnails/hb.jpg">
        <div class="category-name">HolidaysBox Special</div>
        </a></li>
      
      <!--                <li class="circle-box advcr-box"><a class="circla" href=""></a></li>

                    <li class="circle-box family-box"><a class="circla" href=""></a></li>

                    <li class="circle-box luxry-box"><a  class="circla" href=""></a></li>

                    <li class="circle-box hs-box"><a class="circla" href=""></a></li>-->
      
            <li class="circle-box"> <a class="" href="http://www.holidaysbox.com/luxurious"><img class="cicle-image" width="100" height="100" title="" alt="" src="http://www.holidaysbox.com/uploads/thumbnails/regal.jpg">
        <div class="category-name">Luxurious</div>
        </a></li>
      
      <!--                <li class="circle-box advcr-box"><a class="circla" href=""></a></li>

                    <li class="circle-box family-box"><a class="circla" href=""></a></li>

                    <li class="circle-box luxry-box"><a  class="circla" href=""></a></li>

                    <li class="circle-box hs-box"><a class="circla" href=""></a></li>-->
      
            <li class="circle-box"> <a class="" href="http://www.holidaysbox.com/honeymoon"><img class="cicle-image" width="100" height="100" title="" alt="" src="http://www.holidaysbox.com/uploads/thumbnails/honeymoon.jpg">
        <div class="category-name">Honeymoon</div>
        </a></li>
      
      <!--                <li class="circle-box advcr-box"><a class="circla" href=""></a></li>

                    <li class="circle-box family-box"><a class="circla" href=""></a></li>

                    <li class="circle-box luxry-box"><a  class="circla" href=""></a></li>

                    <li class="circle-box hs-box"><a class="circla" href=""></a></li>-->
      
            <li class="circle-box"> <a class="" href="http://www.holidaysbox.com/adventure"><img class="cicle-image" width="100" height="100" title="" alt="" src="http://www.holidaysbox.com/uploads/thumbnails/adventure3.jpg">
        <div class="category-name">Adventure</div>
        </a></li>
      
      <!--                <li class="circle-box advcr-box"><a class="circla" href=""></a></li>

                    <li class="circle-box family-box"><a class="circla" href=""></a></li>

                    <li class="circle-box luxry-box"><a  class="circla" href=""></a></li>

                    <li class="circle-box hs-box"><a class="circla" href=""></a></li>-->
      
            <li class="circle-box"> <a class="" href="http://www.holidaysbox.com/family"><img class="cicle-image" width="100" height="100" title="" alt="" src="http://www.holidaysbox.com/uploads/thumbnails/family1.jpg">
        <div class="category-name">Family</div>
        </a></li>
      
      <!--                <li class="circle-box advcr-box"><a class="circla" href=""></a></li>

                    <li class="circle-box family-box"><a class="circla" href=""></a></li>

                    <li class="circle-box luxry-box"><a  class="circla" href=""></a></li>

                    <li class="circle-box hs-box"><a class="circla" href=""></a></li>-->
      
          </ul>
  </div>
</div>
<div class="footer-section">
  <div class="footer-module text-center"> <a class="footera" href="http://www.holidaysbox.com/">Home</a> |
	    <a class="footera" href="http://www.holidaysbox.com/about-us">About Us</a> |
        <a class="footera" href="http://www.holidaysbox.com/faq">Faq</a> |
        <a class="footera" href="http://www.holidaysbox.com/careers">Careers</a> |
        <a class="footera" href="http://www.holidaysbox.com/mice-tours">MICE Tours</a> |
        <a class="footera"  href="http://www.holidaysbox.com/destinations">Holiday Destinations</a> | <a class="footera"  href="http://www.holidaysbox.com/contact-us">Contact Us</a>
    </ul>
    <p class="footer-text">Copyright &copy; 2014-2017 holidaysbox.com. All Rights Reserved.</p>
  </div>
</div>
<script src="js/jqeasy.dropdown.js" type="text/javascript"></script>
</body></html>